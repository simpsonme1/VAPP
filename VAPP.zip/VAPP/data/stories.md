## fallback

- utter_default



## greeting path 1

* greet

- utter_greet


## greeting path 2

* greet_ask

- utter_greet

- utter_reply



## fine path 1

* fine_normal

- utter_help



## fine path 2

* fine_ask

- utter_reply



## news path

* news

- utter_ofc

- action_get_news



## thanks path 1

* thanks

- utter_anything_else



## bye path 1

* bye

- utter_bye



## help path

* help

- utter_help



## okay path

* okay

- utter_anything_else



## getting_started path

* getting_started

- utter_pseudocode



## pseudocode path

* pseudocode_tips

- utter_pseudocode_tips



## style_tips path

* style_tips

- utter_style_tips



## get_compile_error_type_syntax path

* compile_error

- utter_get_compiler_error_type

* syntaxError

- utter_syntaxError

* user_says_yes

- utter_syntaxError1

* user_says_yes

- utter_syntaxError2

* user_says_yes

- utter_syntaxError3

* user_says_yes

- utter_syntaxError4

* user_says_yes

- utter_syntaxError5

* user_says_yes



## get_compile_error_type_name path

* compile_error

- utter_get_compiler_error_type

* nameError

- utter_nameError

* user_says_yes

- utter_nameError1

* user_says_yes

- utter_nameError2

* user_says_yes

- utter_nameError3

* user_says_yes



## get_compile_error_type_indentation path

* compile_error

- utter_get_compiler_error_type

* indentationError

- utter_indentationError

* user_says_yes

- utter_indentationError1

* user_says_yes

- utter_indentationError2

* user_says_yes

- utter_indentationError3

* user_says_yes



## get_compile_error_type_type path

* compile_error

- utter_get_compiler_error_type

* typeError

- utter_typeError

* user_says_yes

- utter_typeError1

* user_says_yes

- utter_typeError2

* user_says_yes

- utter_typeError3

* user_says_yes

- utter_typeError4

* user_says_yes


## userSaysNo1 path

* user_says_no

- utter_ready?

* ready

- utter_fixed?

* user_says_no


## userSaysNo2 path

* user_says_no

- utter_ready?

* ready

- utter_fixed?

* user_says_yes

- utter_awesome
