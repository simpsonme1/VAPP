## intent:ready
- ready
- I am ready
- i am ready
- I'm ready
- Im ready
- It's ready
- OK ready
- okay ready
- okay im ready
- okay I'm ready
- okay I am ready now
- ready now
- now ready

## intent:greet
- hey
- hello
- hi
- Hi
- Heyyyy
- Hiiii
- Good morning
- Good afternoon
- Good evening
- g'day to you
- hewo
- hello to you
- Greetings
- hi there!
- hey there

## intent:greet_ask
- hey, how are you?
- Hi, how are you?
- How's it going?
- How goes it?
- What's up?
- How are you?
- whattup
- What's going on?
- What's going on with you?

## intent:fine_ask
- I am good, how are you doing?
- I'm fine, how are you?
- I'm good, how are you?
- Good, and you?
- Alright. You?
- Doing well. How are you?
- I'm okay. What about you?
- Good, wbu?
- good wbu
- I am doing well. How are you?
- Well. How is your day?
- can't complain. What about you?
- fine. And you?

## intent:fine_normal
- I am doing great
- I'm doing great
- I'm fine
- I'm good
- Can't complain.
- no complaints here
- Okay
- alright
- Good
- Well
- Doing well
- Doing good
- doing alright
- Excellent!
- exceptional
- Wonderful
- I'm doing fantastic.

## intent:less_than_great_normal
- not well
- Less than average
- unfortunately, I'm not doing great
- not great
- Not so great
- I'm not doing well.
- Not doing good.
- I'm having troubles.
- ehh

## intent:less_than_great_ask
- not well. Wbu?
- Less than average. How are you?
- Not well. I hope you are doing better than me.
- I hope your day is going better than mine.
- ehh. you?
- i'm having some troubles. How are you?

## intent:news
- Share some latest news around the [world](category)?
- Share some latest news in [sports](category)?
- What is going on in [technology](category)?
- Tell me some news about [fashion](category)
- Tell me some news about [business](category)
- Tell me some news about [arts](category)
- What is going on in [arts](category)
- What is cooking in [food](category)
- [movies](category)

## intent:thanks
- Thanks!
- Thank you so much
- thank you
- Ty
- tanks
- thanks
- thank u :)

## intent:bye
- No, I am good as of now. Bye
- Bye
- Bbye
- see ya
- ttyl
- Talk to you later
- Thanks, bye.
- Goodbye
- Bye bye
- g'day
- Have a good day.
- have a good rest of your day

## intent:help
- Hello, I need help.
- I am having trouble.
- help please
- plz help
- I need assistance
- could you provide me with some guidance please?
- Can you help me?
- Can you help me get to the solution?

## intent:okay
- okay
- alright
- let me do that
- Sounds good.
- I will work on that.

## intent:getting_started
- I'm unsure where to begin.
- idk where to start
- How do I start?
- I'm confused about the assigment.

## intent:pseudocode_tips
- Give me tips for writing pseudocode.
- Okay, give me some tips for my pseudocode please.
- Plz give me pseudocode help.
- How can I write pseudocode?
- How do I write pseudocode?
- psuedocode

## intent:compile_error
- my code won't compile
- I have a compile error.
- I have a compilation error.
- I have a compiler error.
- My code won't run.
- compile-time error
- compilation error
- compilation
- compile help
- help with compiling
- I need help with compiling my code.
- Help me with compiling.

## intent:style_tips
- Give me coding tips.
- Give me some tips to write good code.
- Can you help me write good code?
- Can you help me to write better code?
- How to write expert style code?
- Help me write good code.
- coding tips
- best practice tips
- expert style code
- good code
- tips
- good tips
- tips on writing code

## intent:user_says_yes
- yes
- yeah
- ye
- yes ma'am
- yes sir
- ya
- yep
- yeppers
- yes'm
- yes it is
- it is

## intent:user_says_no
- no
- nope
- no sir
- no ma'am
- nopers
- nah
- it is not

## intent: syntaxError
- SyntaxError
- syntax
- syntax error
- I have a syntaxerror
- It is a syntax error
- It's SyntaxError
- I have a syntax compilation error.

## intent: typeError
- TypeError
- type error
- typeerror
- I have a type error
- I have a typeerror
- It's a type error
- I have a type compilation error.

## intent: indentationError
- IndentationError
- indentation error
- indent error
- indentationerror
- i have an indent error
- It's an indentation error.
- I have an indentation compilation error.

## intent: nameError
- NameError
- name error
- name
- nameerror
- I have a name error
- I have a name compilation error.
- It is a name error.
- name errr




